package com.crm.clientservice;

import java.io.Serializable;

public class Cliser implements Serializable{

/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    private int serviceId;
    private int clientId;
}
